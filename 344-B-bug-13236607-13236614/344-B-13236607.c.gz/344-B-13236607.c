#include <stdio.h>

int main(int argc, char *argv[])
{
    int a, b, c, x, y, z, s;
    scanf("%d %d %d", &a, &b, &c);
    s = a + b + c;
    if (s % 2)
    {
        printf("Impossible");
        return 0;
    }
    s /= 2;
    if (s - c >= 0)
        x = s - c;
    else
    {
        printf("Impossible");
        return 0;
    }
    if (s - a >= 0)
        y = s - a;
    else
    {
        printf("Impossible");
        return 0;
    }
    if (s - b >= 0)
        z = s - b;
    else
    {
        printf("Impossible");
        return 0;
    }
    printf("%d %d %d", x, y, z);
}