#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main(int argc, char *argv[])
{
    int a, b=0, count=1, i, j, sum=0;
    char st[1000];
    scanf("%s", &st);
    for(i=0;st[i];i++){
        a = st[i] - '0';
        if(a>1 && b==0){
            st[i] = '1';
            b=1;
        }
        if(b==1){
            st[i] = '1';
        }
    }
    j = strlen(st);
    for(i=j-1;i>=0;i--){
        a = st[i] - '0';
        sum+= (a*count);
        count*=2;
    }
    printf("%d", sum);
    return 0;
}