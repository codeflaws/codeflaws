#include<stdio.h>
#include<string.h>

int main(int argc, char *argv[])
{
    int i;
    scanf("%d",&i);
    switch(i)
    {
        case 1: printf("2");break;
        case 2: printf("3");break;
        case 3: printf("1");break;
        case 4: printf("2");break;
        case 5: printf("1");break;

    }
    return 0;
       }
