#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define LIM 42
#define MAX 500010
#define clr(ar) memset(ar, 0, sizeof(ar))
#define read() freopen("lol.txt", "r", stdin)

int n, q, parent[MAX];
double dp[LIM + 2][MAX];

int main(int argc, char *argv[]){
    double r, z, res;
    int i, j, k, l, x, y, v, flag;

    while (scanf("%d", &q) != EOF){
        if (q == 0) break;

        n = 1, parent[1] = 1, dp[0][1] = 1.0;
        while (q--){
            scanf("%d %d", &flag, &v);
            if (flag == 1){
                x = ++n;
                dp[0][x] = 1.0, parent[x] = v;
                for (j = 1; j <= LIM; j++){
                    if (j == 1){
                        r = dp[j][v];
                        dp[j][v] = dp[j][v] + (0.5 * (1.0 - dp[j][v]) * dp[j - 1][x]);
                    }
                    else{
                        z = r, r = dp[j][v];
                        dp[j][v] = (dp[j][v] - (0.5 * z)) / (1.0 - (0.5 * z));
                        dp[j][v] = dp[j][v] + (0.5 * (1.0 - dp[j][v]) * dp[j - 1][x]);
                    }

                    if (v == parent[v]) break;
                    x = v, v = parent[v];
                }
            }
            else{
                res = 0.0;
                for (j = 1; j < LIM; j++) res += ((dp[j][v] - dp[j + 1][v]) * j);
                printf("%0.12f\n", res + 1e-15);
            }
        }
    }
    return 0;
}
